# DevDash – Week 3 Accessibility & UX

An accessibility-focused frontend interface developed for the YuvaIntern Week 3 task.

## Accessibility improvements
- Skip-to-content link
- Semantic header, nav, main, section, article and footer elements
- Accessible mobile navigation state
- Visible keyboard focus indicators
- Keyboard-operable buttons and dialog
- ARIA dialog, aria-modal, aria-labelledby and aria-describedby
- aria-pressed states for interactive checklist controls
- Accessible names for icon/menu/close buttons
- Focus restoration after modal close
- Readable contrast and non-color-only interaction states
- Responsive layouts for mobile and desktop

## Audit approach
Run the project with a local server and inspect it using Chrome Lighthouse or WAVE. Review keyboard navigation, headings, landmarks, form/control names, focus visibility, color contrast and dialog behavior.

## Run
Open `index.html` in a browser or use VS Code Live Server.
