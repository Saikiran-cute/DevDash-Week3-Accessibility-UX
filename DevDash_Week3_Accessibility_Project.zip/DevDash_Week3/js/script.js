const menuButton = document.querySelector(".menu-toggle");
const nav = document.querySelector("#site-menu");

if (menuButton && nav) {
  menuButton.addEventListener("click", () => {
    const open = nav.classList.toggle("open");
    menuButton.setAttribute("aria-expanded", String(open));
    menuButton.setAttribute("aria-label", open ? "Close navigation menu" : "Open navigation menu");
  });

  nav.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
    nav.classList.remove("open");
    menuButton.setAttribute("aria-expanded", "false");
    menuButton.setAttribute("aria-label", "Open navigation menu");
  }));
}

const dialog = document.querySelector("#articleDialog");
const dialogTitle = document.querySelector("#dialogTitle");
const dialogContent = document.querySelector("#dialogContent");
const closeDialog = document.querySelector("#closeDialog");
const dialogDone = document.querySelector("#dialogDone");
let lastFocused = null;

function openArticle(button) {
  lastFocused = button;
  dialogTitle.textContent = button.dataset.title;
  dialogContent.textContent = button.dataset.content;
  dialog.classList.remove("hidden");
  closeDialog.focus();
}

function closeArticle() {
  dialog.classList.add("hidden");
  if (lastFocused) lastFocused.focus();
}

document.querySelectorAll(".read-more").forEach(button => {
  button.addEventListener("click", () => openArticle(button));
});
closeDialog.addEventListener("click", closeArticle);
dialogDone.addEventListener("click", closeArticle);

dialog.addEventListener("click", event => {
  if (event.target === dialog) closeArticle();
});

document.addEventListener("keydown", event => {
  if (event.key === "Escape" && !dialog.classList.contains("hidden")) {
    closeArticle();
  }
});

document.querySelectorAll(".check-item").forEach(button => {
  button.addEventListener("click", () => {
    const selected = button.getAttribute("aria-pressed") === "true";
    button.setAttribute("aria-pressed", String(!selected));
    const icon = button.querySelector("span");
    icon.textContent = selected ? "○" : "✓";
  });
});
